## Test environments
* ubuntu 18.04: R 3.6.3
* ubuntu 16.04 (on GitHub Actions): R 3.5.3, R 3.6.3
* macOS (on GitHub Actions): R-devel, R 3.6.3
* windows (on GitHub Actions): R 3.6.3
* win-builder: R-devel, R-release, R-oldrelease

## R CMD check results

0 errors | 0 warnings | 0 notes

## revdep checks

All reverse dependencies have been checked. 
There are two packages with check issues caused by this release, which have patches ready to submit.

These packages which will be patched are:
* hts
* forecastHybrid
